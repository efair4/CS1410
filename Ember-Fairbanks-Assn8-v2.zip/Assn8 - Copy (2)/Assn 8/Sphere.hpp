#ifndef _SPHERE_HPP_
#define _SPHERE_HPP_

#include "Geometry.hpp"

class Sphere : public Geometry {
public:
	Sphere(std::string, double);
	virtual double computeSurface();
	virtual double computeVolume();
	
private:
	double m_radius;
	const double PI = 3.14159;
};
#endif