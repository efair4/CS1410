#include <iostream>

#include "BigInteger.hpp"

void factorial(unsigned int); //Allows factorials to be calculated through utilizing the BigInteger class

int main()
{
	BigInteger zero;
	BigInteger fromIntValue(3982379786927309886);
	BigInteger fromStringValue("1234567889767895674657354432431212334263574687598690");
	factorial(999);

	BigInteger result1 = BigInteger::multiply(fromIntValue, 2);
	BigInteger result2 = BigInteger::multiply(fromStringValue, 2);

	result1.display(true);
	result2.display(true);

	return 0;
}
void factorial(unsigned int number) {
	BigInteger total(number);
	for (int i = number-1; i > 0; i--) {
		total = BigInteger::multiply(total, i);
	}
	total.display(true);
}