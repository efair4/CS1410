#ifndef _BINARY_SEARCH_TREE_
#define _BINARY_SEARCH_TREE_

template <typename T>
class BinarySearchTree {
public:
	//Constructor for the BinarySearchTree class that sets m_root to nullptr.
	BinarySearchTree() : m_root(nullptr) {}

	//Destructor for the BinarySearchTree class.
	~BinarySearchTree() { destroyTree(m_root); }

	//Inserts a value if it is not already in the tree. Returns true 
	//if the value can be inserted and false if it is already there.
	bool insert(T value);

	//Deletes a value from the tree
	void remove(T value);

	//Checks to see if a value exists in the tree
	bool search(T value);

	//Returns a count of all nodes in the tree
	unsigned int numberNodes();

	//Returns a count of all the leaf nodes in the tree
	unsigned int numberLeafNodes();

	//Returns the height of the tree
	unsigned int height();

	//Displays the elements in the tree
	void display();

private:
	//Class to control the nodes in the binary tree,
	template <typename T>
	class TreeNode {
	public:
		//Constructor for the TreeNode class
		TreeNode(T data) :
			data(data),
			left(nullptr),
			right(nullptr)
		{}
		//Holds the data in each node.
		T data;
		//Left pointer for each node.
		TreeNode<T>* left;
		//Right pointer for each node.
		TreeNode<T>* right;
	};
	//Pointer to the first node.
	TreeNode<T>* m_root;

	//Helper function for the destructor.
	void destroyTree(TreeNode<T>* node);

	//Helper function for the above insert method that places a 
	//new node into the correct place in the tree.
	void insert(TreeNode<T>*& node, TreeNode<T>* newNode);

	//Helper function for the above search method that returns
	//true or false depending on if the sent value is in the tree.
	bool search(TreeNode<T>*& node, TreeNode<T>* newNode);

	//Helper function for the above remove function that finds the
	//correct node to remove and then calls the below remove function.
	void remove(T value, TreeNode<T>*& node);

	//This remove function actually removes the node and reconnects
	//the tree.
	void remove(TreeNode<T>*& node);

	//Helper function for the above display function.
	void display(TreeNode<T>* node);

	//Helper function for the above numberNodes function.
	unsigned int numberNodes(TreeNode<T>* node);

	//Helper function for the above numberLeafNodes function.
	unsigned int numberLeafNodes(TreeNode<T>* node);

	//Helper function for the above height function.
	unsigned int height(TreeNode<T>* node);
};

template <typename T>
void BinarySearchTree<T>::destroyTree(TreeNode<T>* node) {
	if (!node) return;
	destroyTree(node->left);
	destroyTree(node->right);
	delete node;
}

template <typename T>
bool BinarySearchTree<T>::insert(T value) {
	TreeNode<T>* newNode = new TreeNode<T>(value);
	bool valueExists = search(value);
	if (!valueExists) {
		insert(m_root, newNode);
	}
	return !valueExists;
}

template <typename T>
void BinarySearchTree<T>::insert(TreeNode<T>*& node, TreeNode<T>* newNode) {
	if (node == nullptr) {
		node = newNode;
	}
	else  if (newNode->data < node->data) {
		insert(node->left, newNode);
	}
	else {
		insert(node->right, newNode);
	}
}

template <typename T>
void BinarySearchTree<T>::remove(T value) {
	bool valueExists = search(value);
	if (valueExists) {
		remove(value, m_root);
	}
}

template <typename T>
void BinarySearchTree<T>::remove(T value, TreeNode<T>*& node) {
	if (value < node->data) {
		remove(value, node->left);
	}
	else if (value>node->data) {
		remove(value, node->right);
	}
	else {
		remove(node);
	}
}

template <typename T>
void BinarySearchTree<T>::remove(TreeNode<T>*& node) {
	if (node->left == nullptr) {
		TreeNode<T>* temp = node;
		node = node->right;
		delete temp;
	}
	else if (node->right == nullptr) {
		TreeNode<T>* temp = node;
		node = node->left;
		delete temp;
	}
	else {
		insert(node->right, node->left);
		TreeNode<T>* temp = node;
		node = node->right;
		delete temp;
	}
}

template <typename T>
bool BinarySearchTree<T>::search(T value) {
	TreeNode<T>* newNode = new TreeNode<T>(value);
	return search(m_root, newNode);
}

template <typename T>
bool BinarySearchTree<T>::search(TreeNode<T>*& node, TreeNode<T>* newNode) {
	if (node == nullptr) {
		return false;
	}
	else if (newNode->data == node->data) {
		return true;
	}
	else if (newNode->data < node->data) {
		search(node->left, newNode);
	}
	else if (newNode->data > node->data) {
		search(node->right, newNode);
	}
	else {
		return false;
	}
}

template <typename T>
void BinarySearchTree<T>::display() {
	display(m_root);
}

template <typename T>
void BinarySearchTree<T>::display(TreeNode<T>* node) {
	if (node != nullptr) {
		display(node->left);
		std::cout << node->data << std::endl;
		display(node->right);
	}
}

template <typename T>
unsigned int BinarySearchTree<T>::numberNodes() {
	return numberNodes(m_root);
}

template <typename T>
unsigned int BinarySearchTree<T>::numberNodes(TreeNode<T>* node) {
	if (node == nullptr) { return 0; }
	else{
		if (node->left == nullptr && node->right == nullptr) {
			return 1;
		}
		else {
			return (1 + (numberNodes(node->left) + numberNodes(node->right)));
		}
	}
}

template <typename T>
unsigned int BinarySearchTree<T>::numberLeafNodes() {
	return numberLeafNodes(m_root);
}

template <typename T>
unsigned int BinarySearchTree<T>::numberLeafNodes(TreeNode<T>* node) {
	if (node == nullptr) { return 0; }
	else {
		if (node->left == nullptr && node->right == nullptr) {
			return 1;
		}
		else {
			return numberLeafNodes(node->left) + numberLeafNodes(node->right);
		}
	}
}

template <typename T>
unsigned int BinarySearchTree<T>::height() {
	return height(m_root);
}

template <typename T>
unsigned int BinarySearchTree<T>::height(TreeNode<T>* node) {
	if (node == nullptr) {return 0;}
	else{	
		int leftHeight = height(node->left);
		int rightHeight = height(node->right);

		if (leftHeight > rightHeight) {
			return(leftHeight + 1);
		}
		else {
			return(rightHeight + 1);
		}
	}
}
#endif