#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<algorithm>
#include<ctime>
#include<cstdlib>
#include<sstream>
#include"BinarySearchTree.hpp"

//Uses sstream to split the sentences into separate
//words and returns a vector filled with those words.
std::vector<std::string> split(std::string s);

//Generates a random number
int myrandom(int i) { return std::rand() % i; }

void testTree();

//Outputs the information about a binary tree.
void treeStats(BinarySearchTree<std::string>&);

//Gets rid of the punctuation in the sent string.
std::string noPunct(std::string);

int main() {
	//testTree();
	std::srand(unsigned (time(0)));
	BinarySearchTree<std::string> searchTree;
	std::vector<std::string> dict;
	std::vector<std::string> letter;
	std::string dictWord;
	std::string letterWord;
	std::string sentence;
	int misspelled = 0;

	std::ifstream dictFile("Dictionary.txt");
	if (!dictFile) {
		std::cout << "Error reading Dictionary.txt" << std::endl;
		return 0;
	}

	std::ifstream letterFile("Letter.txt");
	if (!letterFile) {
		std::cout << "Error reading Letter.txt" << std::endl;
		return 0;
	}

	while (std::getline(dictFile, dictWord)) {
		dict.push_back(dictWord);
	}

	while (std::getline(letterFile, letterWord)) {
		sentence += letterWord + " ";
	}
	letter = split(sentence);
	
	for (int i = 0; i < letter.size();i++){
		letter[i] = noPunct(letter[i]);
	}

	std::random_shuffle(dict.begin(), dict.end());
	for (int i = 0; i < dict.size(); i++) {
		searchTree.insert(dict[i]);
	}
	treeStats(searchTree);

	for (int i = 0; i < letter.size(); i++) {
		bool found=searchTree.search(letter[i]);
		if (found == false) {
			misspelled++;
		}
	}
	
	std::cout << "There were " << misspelled << " misspelled words in the file." << std::endl;

	return 0;
}

std::vector<std::string> split(std::string s) {
	std::vector<std::string> result;
	std::istringstream istr(s);
	std::string item;
	while (istr >> item) {
		result.push_back(item);
	}
	return result;
}

std::string noPunct(std::string word) {
	std::transform(word.begin(), word.end(), word.begin(), ::tolower);
	std::string newString="";
	for (int i = 0; i < word.length(); i++) {
		if (!ispunct(word[i])) {
			newString += word[i];
		}
	}
	return newString;
}

void treeStats(BinarySearchTree<std::string>& tree) {
	std::cout << "---Tree Stats---" << std::endl;
	std::cout << "Total Nodes: " << tree.numberNodes() << std::endl;
	std::cout << "Leaf Nodes: " << tree.numberLeafNodes() << std::endl;
	std::cout << "Tree Height: " << tree.height() << std::endl;
	std::cout << std::endl;
}

void testTree()
{
	BinarySearchTree<std::string> tree;
	//
	// Add a bunch of values to the tree
	tree.insert("Olga");
	tree.insert("Tomeka");
	tree.insert("Benjamin");
	tree.insert("Ulysses");
	tree.insert("Tanesha");
	tree.insert("Judie");
	tree.insert("Tisa");
	tree.insert("Santiago");
	tree.insert("Chia");
	tree.insert("Arden");

	//
	// Make sure it displays in sorted order
	tree.display();

	//
	// Try to add a duplicate
	std::cout << std::endl << "---- adding a duplicate ----" << std::endl;
	if (tree.insert("Tomeka"))
	{
		std::cout << "oops, shouldn't have returned true from the insert" << std::endl;
	}
	tree.display();

	//
	// Remove an existing value from the tree
	std::cout << std::endl << "---- removing an existing value ----" << std::endl;
	tree.remove("Olga");
	tree.display();

	//
	// Remove a value that was never in the tree, hope it doesn't crash!
	tree.remove("Karl");

	//
	// Check the tree stats
	std::cout << std::endl << "---- checking the tree stats ----" << std::endl;
	std::cout << "Expecting 9 nodes, found " << tree.numberNodes() << std::endl;
	std::cout << "Expecting 4 leaf nodes, found " << tree.numberLeafNodes() << std::endl;
	std::cout << "Expecting height of 6, found " << tree.height() << std::endl;
}