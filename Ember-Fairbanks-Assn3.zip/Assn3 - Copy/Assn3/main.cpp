//Ember Fairbanks
//A02044817
#include<iostream>
#include<fstream>
#include<vector>

#include "IPRecord.cpp"

//Accepts an integer as a key to search for in a binary search.
//It then returns a position to insert the new IPRecord if it is
//not found.
int binarySearch(int, int);  
//Sorts a vector by the frequency values.
void selectionSort(std::vector<IPRecord*>&, unsigned int);
//Used when the position returned from the binary search is 0.
//It tells whether or not the given value matches the 0 spot in the vector.
bool findZero(std::vector<IPRecord*>, int);
//Prints out the number of values with a certain frequency to the console.
void printIPInfo(std::vector<IPRecord*>, unsigned int, int);

int main() {
	int value;
	int pos;
	int size;
	std::vector<IPRecord*> records;
	std::ifstream infile ("input.txt");
	

	if (!infile) {
		std::cout << "Cannot open file. Unable to continue" << std::endl;
		return 0;
	}
	
	infile >> size;
	for (int indexValue = 0; indexValue < size;indexValue++) {
		infile >> value;
		pos= binarySearch(value, indexValue);
		if (pos < 0) {
			records[-pos]->incrementFrequency();
		}
		else if (pos == 0 && indexValue == 0) {
			records.insert(records.begin() + pos, new IPRecord(value));
		}
		else if (pos == 0) {
			bool foundZero;
			foundZero = findZero(records, value);
			if (foundZero == false) {
				records.insert(records.begin() + pos, new IPRecord(value));
			}
			else {
				records[pos]->incrementFrequency();
			}
		}
		else {
			records.insert(records.begin() + pos, new IPRecord(value));
		}
	}
	unsigned int recordsSize = records.size();
	selectionSort(records, recordsSize);
	printIPInfo(records, recordsSize, size);
	infile.close();
	std::vector<IPRecord*>().swap(records);

	return 0;
}

int binarySearch(int key, int j) {
	static std::vector<int> binaryVector;
	int position;
	int lowPos = 0;
	int highPos;
	if (j == 0) {
		highPos = binaryVector.size();
	}
	else {
		highPos = binaryVector.size() - 1;
	}
	int middle;
	bool found = false;
	while (found==false && lowPos <= highPos) {
		middle = (lowPos + highPos) / 2;
		if (j == 0) {
			binaryVector.insert(binaryVector.begin() + 0, key);
			found = true;
		}
		else if (binaryVector[middle] == key) {
			found = true;
		}
		else if (binaryVector[middle] > key) {
			highPos = middle - 1;
		}
		else if (binaryVector[middle] < key) {
			lowPos = middle + 1;
		}
		
	}
	if (found == false) {
		position = lowPos;
		binaryVector.insert(binaryVector.begin() + position, key);
	}
	else {
		position = -middle;
	}
	return position;
}

void selectionSort(std::vector<IPRecord*>& recordVector, unsigned int vectorSize) {
	unsigned int numberOfIPs=0;
	unsigned int freq=0;
	for (unsigned int start = 0; start < vectorSize - 1; start++) {
		unsigned int minpos = start;
		for (unsigned int scan = start + 1; scan < vectorSize; scan++) {
			if (recordVector[scan]->getFrequency() < recordVector[minpos]->getFrequency()) {
				minpos = scan;
			}
		}
		std::swap(recordVector[start], recordVector[minpos]); 
			
	}
}
bool findZero(std::vector<IPRecord*> recordVector, int ip) {
	bool isFound;
	if (NULL == recordVector[0]->getIP() ) {
		isFound = false;
	}
	else if(recordVector[0]->getIP() == ip) {
		isFound = true;
	}
	else {
		isFound = false;
	}
	return isFound;
}

void printIPInfo(std::vector<IPRecord*> recordVector, unsigned int vectorSize, int startingSize) {
	unsigned int count = 1 ;
	int freq;
	for (unsigned int index = 1; index < vectorSize; index++) {
		if (recordVector[index]->getFrequency() == recordVector[index - 1]->getFrequency()) {
			count++;
			if (index == vectorSize - 1) {
				freq = recordVector[index]->getFrequency();
				std::cout << count << " IPs with a frequency of " << freq << std::endl;
			}
		}
		
		else {
			freq = recordVector[index-1]->getFrequency();
			std::cout << count << " IPs with a frequency of " << freq << std::endl;
			count = 1;
		}
	}
	std::cout << "There were " << startingSize << " IPs addresses identified during the frequency analysis." << std::endl;
}

