#include <iostream>
#include <vector>
#include "Box.hpp"
#include "Sphere.hpp"

void report(Geometry* obj);

int main() {
	std::vector<Geometry*> items;

	items.push_back(new Box("Box 1", 1, 2, 3));
	items.push_back(new Box("Box 2", 2, 3, 4));
	items.push_back(new Sphere("Sphere 1", 5));
	items.push_back(new Sphere("Sphere 2", 6));

	for (unsigned int i = 0; i < items.size(); i++) {
		report(items[i]);
	}

	for (unsigned int j = 0; j < items.size(); j++) {
		delete items[j];
		items[j] = nullptr;
	}

	return 0;
}

void report(Geometry* obj) {
	std::cout << "----- Geometry Report -----\n" << std::endl;
	std::cout << "Type: " << obj->getType() << std::endl;
	std::cout << "Name: " << obj->getName() << std::endl;
	std::cout << "Volume: " << obj->computeVolume() << std::endl;
	std::cout << "Surface Area: " << obj->computeSurface() << "\n" << std::endl;
}