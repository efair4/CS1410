#include "Shark.hpp"

Shark::Shark(unsigned int starvation, unsigned int starvationPeriod, unsigned int gestation, unsigned int gestationPeriod, unsigned int startingAge) :
	m_starvation(starvation),
	m_starvationPeriod(starvationPeriod),
	Fish(gestation, gestationPeriod, startingAge)
{
}

void Shark::eat() {
	m_starvation = m_starvationPeriod;
}

char Shark::toChar() {
	if (m_dead==true) {
		return 'x';
	}
	else if(m_direction == Direction::up) {
		return 'u';
	}
	else if (m_direction == Direction::right) {
		return 'r';
	}
	else if (m_direction == Direction::left) {
		return 'l';
	}
	else if (m_direction == Direction::down) {
		return 'd';
	}
}

void Shark::timeUpdate() {
	if (m_starvation == 0) {
		m_dead = true;
	}
	else {
		m_starvation--;
	}
	
	Fish::timeUpdate();
}

void Shark::point(std::vector<std::string>& map) {
	unsigned int row=0;
	unsigned int col=0;
	unsigned int tempFishRow;
	unsigned int tempFishCol;
	bool isFish;

	
	for (int i = 0; i < 5; i++) {
		isFish = checkFish(map, row, i);
		if (isFish == true) {
			tempFishRow = row;
			tempFishCol = i;
		}
	}
	row = 4;
	for (int i = 0; i < 5; i++) {
		isFish = checkFish(map, row, i);
		if (isFish == true) {
			tempFishRow = row;
			tempFishCol = i;
		}
	}
	for (int i = 1; i < 4; i++) {
		isFish = checkFish(map, i, col);
		if (isFish == true) {
			tempFishRow = i;
			tempFishCol = col;
		}
	}
	col = 4;
	for (int i = 1; i < 4; i++) {
		isFish = checkFish(map, i, col);
		if (isFish == true) {
			tempFishRow = i;
			tempFishCol = col;
		}
	}
	row = 1;
	for (int i = 1; i < 4; i+=2) {
		isFish = checkFish(map, row, i);
		if (isFish == true) {
			tempFishRow = row;
			tempFishCol = i;
		}
	}
	row = 3;
	for (int i = 1; i < 4; i+=2) {
		isFish = checkFish(map, row, i);
		if (isFish == true) {
			tempFishRow = row;
			tempFishCol = i;
		}
	}
	col = 2;
	isFish = checkFish(map, row, col);
	if (isFish == true) {
		tempFishRow = row;
		tempFishCol = col;
	}
	row = 1;
	isFish = checkFish(map, row, col);
	if (isFish == true) {
		tempFishRow = row;
		tempFishCol = col;
	}
	row = 2;
	col = 1;
	isFish = checkFish(map, row, col);
	if (isFish == true) {
		tempFishRow = row;
		tempFishCol = col;
	}
	col = 3;
	isFish = checkFish(map, row, col);
	if (isFish == true) {
		tempFishRow = row;
		tempFishCol = col;
	}


	switch (tempFishRow) {
	case 0:
		switch (tempFishCol) {
		case 0:
			m_direction = Direction::left;
			break;
		case 1: case 2: case 3:
			m_direction = Direction::up;
			break;
		case 4:
			m_direction = Direction::right;
			break;
		}
		break;
	case 1:
		switch (tempFishCol) {
		case 0: case 1:
			m_direction = Direction::left;
			break;
		case 2:
			m_direction = Direction::up;
			break;
		case 3: case 4:
			m_direction = Direction::right;
			break;
		}
		break;
	case 2:
		switch (tempFishCol) {
		case 0: case 1:
			m_direction = Direction::left;
			break;
		case 3: case 4:
			m_direction = Direction::right;
			break;
		}
		break;
	case 3:
		switch (tempFishCol) {
		case 0: case 1:
			m_direction = Direction::left;
			break;
		case 2:
			m_direction = Direction::down;
			break;
		case 3: case 4:
			m_direction = Direction::right;
			break;
		}
		break;
	case 4:
		switch (tempFishCol) {
		case 0:
			m_direction = Direction::left;
			break;
		case 1: case 2: case 3:
			m_direction = Direction::down;
			break;
		case 4:
			m_direction = Direction::right;
			break;
		}
		break;
	}
	toChar();
}

bool Shark::checkFish(std::vector<std::string>& map, unsigned int row, unsigned int col) {
	if (map[row][col] != '.') {
		return true;
	}
	return false;
}