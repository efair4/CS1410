#include <iostream>
#include <algorithm>
#include <cmath>

#include "BigInteger.hpp"


BigInteger::BigInteger() {
	m_sizeReserved = 4;
	m_digitCount = 0;
	m_number = new char[m_sizeReserved];
	
}
BigInteger::BigInteger(int intValue) {
	fromInt(intValue);
}
BigInteger::BigInteger(std::string strValue) {
	fromString(strValue);
}
// ------------------------------------------------------------------
//
// This method accepts a BigInteger and an integer, multiplies them
// together and returns a new BigInteger with the result.
//
// ------------------------------------------------------------------
BigInteger BigInteger::multiply(const BigInteger& x, unsigned int y)
{
	BigInteger result;
	unsigned int carry = 0;
	unsigned int pos = 0;

	for (unsigned int digit = 0; digit < x.m_digitCount; digit++)
	{
		carry += x.getDigit(digit) * y;
		result.setDigit(pos++, carry % 10);
		carry /= 10;
	}

	while (carry > 0)
	{
		result.setDigit(pos++, carry % 10);
		carry /= 10;
	}

	return result;
}

// ------------------------------------------------------------------
//
// Provides a means to display the BigInteger value.  Optionally, some
// debug information can be displayed by setting the 'debug' parameter
// to true.
//
// ------------------------------------------------------------------
void BigInteger::display(bool debug)
{
	for (unsigned int digit = m_digitCount; digit > 0; digit--)
	{
		std::cout << static_cast<int>(m_number[digit - 1]);
	}

	if (debug)
	{
		std::cout << " [size = " << m_sizeReserved << ", digit count = " << m_digitCount << std::endl;
	}
}
//Copy Constructor
BigInteger::BigInteger(const BigInteger& obj) {
	m_sizeReserved = obj.m_sizeReserved;
	m_number = new char[m_sizeReserved];
	m_digitCount = obj.m_digitCount;
	for (unsigned int position = 0; position < m_sizeReserved; position++) {
		m_number[position] = obj.m_number[position];
	}
}
//Assignment Operator
BigInteger& BigInteger::operator=(const BigInteger& rhs) {
	delete[]m_number;
	m_sizeReserved = rhs.m_sizeReserved;
	m_number = new char[m_sizeReserved];
	m_digitCount = rhs.m_digitCount;
	for (unsigned int position = 0; position < m_digitCount; position++) {
		m_number[position] = rhs.m_number[position];
	}
	return *this;
}

void BigInteger::fromInt(int intValue) {
	m_sizeReserved = 4;
	m_digitCount = 0;
	m_number = new char[m_sizeReserved];
	int i = 0;
	while (intValue>0) {
		int single = intValue % 10;
		intValue = intValue / 10;
		setDigit(i, single);
		i++;
	}

}
void BigInteger::fromString(std::string strValue) {
	m_sizeReserved = 4;
	m_digitCount = 0;
	m_number = new char[m_sizeReserved];
	for (int i = strValue.length()-1, j = 0; i >= 0; i--, j++) {
		this->setDigit(j, strValue[i] - '0');
	}
}
// ------------------------------------------------------------------
//
// Returns the digit as the specified positon.  If the position is greater
// than the number representation, a '0' is returned.  Not the best
// idea in the world, but the best we can do for now, can make this better
// in the future.
//
// ------------------------------------------------------------------
char BigInteger::getDigit(unsigned int position) const
{
	if (position < m_digitCount)
	{
		return m_number[position];
	}

	return '0';
}

void BigInteger::setDigit(unsigned int position, char digit) {
	while (position >= m_sizeReserved) {
		resize();
	}
	m_number[position] = digit;
	if (position >= m_digitCount) {
		m_digitCount = position + 1;
	}
}

void BigInteger::resize() {
	
	m_sizeReserved *= 2;
	char* temp = new char[m_sizeReserved];
	for (int i = 0; i < m_digitCount; i++) {
		temp[i] = m_number[i];
	}
	delete[] m_number;
	m_number = temp;
}
