#include "Box.hpp"

Box::Box(std::string name, double length, double width, double height) :
	Geometry(name,"Box"),
	m_length(length),
	m_width(width),
	m_height(height)
{}

double Box::computeSurface() {
	return 2*(m_length*m_height)+(2*(m_length*m_width))+(2*(m_height*m_width));
}

double Box::computeVolume() {
	return m_length*m_width*m_height;
}