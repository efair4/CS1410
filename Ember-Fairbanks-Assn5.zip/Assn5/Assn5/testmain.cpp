#include <iostream> 
#include "BigInteger.hpp" 
// ------------------------------------------------------------------
// 
// Site to compare long factorial results: http://www.dcode.fr/factorial 
// 
// ------------------------------------------------------------------

BigInteger factorial(BigInteger value) {
	BigInteger result(1);
	for (BigInteger next = 1; next <= value; next++) {
		result *= next;
	} 
	return result;
}

int main() {
	BigInteger one(1234); 
	BigInteger two(9999); 
	BigInteger result = one + two; 
	std::cout << "one + two = " << result << std::endl; 
	std::cout << "one + two (as double) = " << static_cast<double>(result) <<
		std::endl;
	one += two; 
	std::cout << "one += two = " << one << std::endl;
	BigInteger three("1234567890"); 
	BigInteger four("123456789"); 
	BigInteger result2 = three * four; 
	std::cout << "three * four = " << result2 << std::endl; 
	three *= four; 
	std::cout << "three *= four = " << three << std::endl;

	BigInteger f = factorial(123); 
	std::cout << "factorial of 123 is: " << f << std::endl; 
	BigInteger factorialFromWeb("12146304367025329675766243241881295855454217088483382315328918161829235892362167668831156960612640202170735835221294047782591091570411651472186029519906261646730733907419814952960000000000000000000000000000");
	
	BigInteger fact = factorial(444);
	std::cout << "Factorial of 444: " << fact << std::endl;
	BigInteger webfact("2158498229664169381240934846787839775226889334239111392728223447607233042631042944965895776887213024296077212339054998658849891204018104492866994495947417001388293593082167439088059093314188984227262192529101611106575697783060158632729740817887041781761259289671249614896941432316658342541324035061607860084788807031878705407113941818104969441195539788957754275867623964436951956204121568969544244311044174910767746301703339759158843920089875069951677493733632439653643785361337892894743890829823639592393438091920958477378116036284911318112605525567443472572546529014457500199689448626563391668771157373653632348743920358758553646481006718083074707897771944485862025233720134513438067875719209765937568083994743104103131111509435670725368411492614709991617411657892705799801994292203582716735228876600572542523373829941288748504573195572187104386700211469811880824268073730048000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
	
	if (f == factorialFromWeb) {
		std::cout << "My factorial result matches!!" << std::endl;
	}
	else {
		std::cout << "Still work left to do..." << std::endl;
	}

	if (fact == webfact) {
		std::cout << "My factorial result matches!!" << std::endl;
	}
	else {
		std::cout << "Still work left to do..." << std::endl;
	} 
	return 0;
}
