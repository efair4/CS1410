//Version 2.1
#include <iostream> 
#include <algorithm> 
#include <string> 
#include <sstream> 
#include <vector> 
#include <chrono> 
#include <cstdlib> 
#include <ctime>

std::string collapseSpaces(std::string s); 
std::vector<std::string> split(std::string s); 
bool isPalindrome(std::string word, int start, int end); 
bool isWordSymmetric(const std::vector<std::string>& words, int start, int end); 
long vectorSum(const std::vector<int>& data, unsigned int position); 
int vectorMin(const std::vector<int>& data, unsigned int position); 
void quickSort(std::vector<int>& data, int start, int end);

void testPalindromes(); 
void testWordSymmetry(); 
void testVectorSum(); 
void testVectorMin(); 
void testSort();

int main() {
	testPalindromes(); 
	testWordSymmetry(); 
	testVectorSum(); 
	testVectorMin(); 
	testSort();
}
// ------------------------------------------------------------------
// 
// Provided palindrome testing code 
// 
// ------------------------------------------------------------------
void testPalindromes() {
	std::vector<std::string> possiblePallindromes = {
		"radar", 
		"racecar", 
		"Pull up if I pull up", 
		"No lemon no melon", 
		"A dog a panic in a pagoda", 
		"CS 1410 is my favorite class", 
		"Rats live on no evil star", 
		"My code compiles without bugs", 
		"Never odd or even", 
		"Now I see bees I won",
		"Emordnilap palindrme"
	};
	for (auto test : possiblePallindromes) {
		std::string collapsed = collapseSpaces(test); 
		// Collapse any spaces first
		std::cout << "'" << test << "' is "; 
		if (!isPalindrome(collapsed, 0, static_cast<int>(collapsed.length()- 1)))
		{
			std::cout << " NOT ";
		}

		std::cout << "a palindrome." << std::endl;
	}
}

//Split function
std::vector<std::string> split(std::string s) {
	std::vector<std::string> result;
	std::istringstream istr(s);
	std::string item;
	while (istr>>item) {
		//istr >> item;
		result.push_back(item);
	}
	return result;
}

// ------------------------------------------------------------------
// 
// Provided word symmetry testing code 
// 
// ------------------------------------------------------------------
void testWordSymmetry() {
	std::vector<std::string> possibleSymmetric = {
		"You can cage a swallow can't you but you can't swallow a cage can you",
		"Fall leaves as soon as leaves fall", 
		"So patient a nurse to nurse a patient so", 
		"I still say cS 1410 is my favorite class"
	};
	for (auto test : possibleSymmetric) {
		std::transform(test.begin(), test.end(), test.begin(), toupper); //Capitalize all
			auto words = split(test); // Split into words 
			std::cout << "'" << test << "' is "; 
			if (!isWordSymmetric(words, 0, static_cast<int>(words.size() - 1))) {
				std::cout << " NOT ";
			}	
			std::cout << "word symmetric." << std::endl;
	}
}
// ------------------------------------------------------------------
// 
// Provided test vector sum code 
// 
// ------------------------------------------------------------------
void testVectorSum() 
{ 
	std::vector<int> data = { 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89 }; 
	std::cout << "The total sum is: " << vectorSum(data, 0) << std::endl;
}

// ------------------------------------------------------------------
// 
// Provided test vector min code 
// 
// ------------------------------------------------------------------
void testVectorMin() 
{ 
	std::vector<int> data = { 0, 1, 1, 2, 3, 5, 8, -42, 13, 21, 34, 55, 89 }; 
	std::cout << "The minimum value is: " << vectorMin(data, 0) << std::endl; 
}

// ------------------------------------------------------------------
// 
// Provided test quicksorting code 
// 
// ------------------------------------------------------------------
void testSort() {
	std::srand(std::time(NULL)); 
	std::vector<int> data1(100000); 
	std::vector<int> data2(100000);
	for (auto&& item : data1) 
	{ 
		item = std::rand();
	} 
	for (auto&& item : data2) 
	{ 
		item = std::rand(); 
	}
	auto start = std::chrono::high_resolution_clock::now(); 
	quickSort(data1, 0, data1.size() - 1); 
	auto end = std::chrono::high_resolution_clock::now(); 
	std::chrono::duration<double> timeSort = end - start; 
	std::cout << "Quicksort sort time    : " << timeSort.count() << " seconds"<< std::endl;
	start = std::chrono::high_resolution_clock::now(); 
	std::sort(data2.begin(), data2.end());
	end = std::chrono::high_resolution_clock::now(); 
	timeSort = end - start; 
	std::cout << "std::sort sort time    : " << timeSort.count() << " seconds"<< std::endl; 
}

// ------------------------------------------------------------------
// 
// Provided code to remove spaces from a string (and capitalize it) 
// 
// ------------------------------------------------------------------
std::string collapseSpaces(std::string s) 
{ 
	s.erase(std::remove_if(s.begin(), s.end(), isspace), s.end());
	std::transform(s.begin(), s.end(), s.begin(), toupper); // Capitalize all
	return s;
}

// ------------------------------------------------------------------
// 
// Provided quicksort partition code 
// 
// ------------------------------------------------------------------
int partition(std::vector<int>& data, int start, int end) {
	int middle = (start + end) / 2; 
	std::swap(data[start], data[middle]); 
	int pivotIndex = start; 
	int pivotValue = data[start]; 
	for (int scan = start + 1; scan <= end; scan++) {
		if (data[scan] < pivotValue) {
			pivotIndex++;
			std::swap(data[scan], data[pivotIndex]);
		}
	} 
	std::swap(data[pivotIndex], data[start]); 
	return pivotIndex;
}

// ------------------------------------------------------------------
// 
// Provided quicksort code 
// 
// ------------------------------------------------------------------
void quickSort(std::vector<int>& data, int start, int end) {
	if (start < end) {
		int pivot = partition(data, start, end); 
		quickSort(data, start, pivot - 1); 
		quickSort(data, pivot + 1, end);
		if ((end - start) <= 10) {
			unsigned int size = end-start;
			for (unsigned int st = 0; st < size - 1; st++) {
				unsigned int minPos = st;
				for (unsigned int scan = st + 1; scan < size; scan++) {
					if (data[scan] < data[minPos]) {
						minPos = scan;
					}
				}
				std::swap(data[st], data[minPos]);
			}
		}
	}
}

//Palindrome function
bool isPalindrome(std::string word, int start, int end) {
	if (start >= end) {
		return true;
	}
	if (word[start] == word[end]) {
		return isPalindrome(word, ++start, --end);
	}
	else {
		return false;
	}
}

//Word Symmetric function
bool isWordSymmetric(const std::vector<std::string>& words, int start, int end) {
	if (start >= end) {
		return true;
	}
	std::string currentStWord = words[start];
	std::string currentEndWord = words[end];
	int stWordLength = currentStWord.length();
	int endWordLength = currentEndWord.length();
	bool sameLength = stWordLength == endWordLength;
	if (!sameLength) return false;
	int index = 0;
	while (index < stWordLength) {
		if (currentStWord[index] == currentEndWord[index]) {
			index++;
		}
		else {
			return false;
		}
	}	
	return isWordSymmetric(words, ++start, --end);
}

//Sum function
long vectorSum(const std::vector<int>& data, unsigned int position) {
	static long total = 0;
	total += data[position];
	position++;
	if (position < data.size()) {
		vectorSum(data, position);
	}
	else {
		return total;
	}
}

//Minimum function
int vectorMin(const std::vector<int>& data, unsigned int position) {
	static int minimum=data[position];
	position++;
	if (position == data.size()) {
		return minimum;
	}
	if (data[position] < minimum) {
		minimum = data[position];	
	}
	vectorMin(data, position);
}
