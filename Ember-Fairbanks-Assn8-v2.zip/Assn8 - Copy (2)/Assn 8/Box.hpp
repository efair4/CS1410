#ifndef _BOX_HPP_
#define _BOX_HPP_

#include "Geometry.hpp"

class Box : public Geometry {
public:
	Box(std::string, double, double, double);
	virtual double computeSurface();
	virtual double computeVolume();

private:
	double m_length;
	double m_width;
	double m_height;
};
#endif
