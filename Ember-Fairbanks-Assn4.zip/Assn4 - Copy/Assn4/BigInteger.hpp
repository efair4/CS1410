#ifndef _BIGINTEGER_HPP_
#define _BIGINTEGER_HPP_

#include <string>

class BigInteger
{
public:
	BigInteger(); //Default constructor
    BigInteger(int); //Overloaded constructor that accepts an int
	BigInteger(std::string); //Overloaded constructor that accepts a std::string
	static BigInteger multiply(const BigInteger& x, unsigned int y);
	void display(bool debug = false);
	BigInteger(const BigInteger& obj); //Copy Constructor
	BigInteger& operator=(const BigInteger& rhs); //Assignment Operator

private:
	char* m_number;		// Internal representation of the number.
	unsigned int m_sizeReserved;	// Total size of the allocated space used to internally store the number
	unsigned int m_digitCount;	// How many digits are in the number.

	void fromInt(int); //Initializes a BigInteger object from and int.
	void fromString(std::string); //Initializes a BigInteger object from a std::string.
	char getDigit(unsigned int position) const; //Returns the digit at a certain position.
	void setDigit(unsigned int position, char digit); //Populates the array with the values sent.
	void resize(); //Resizes the array if the position sent to setDigit is outside the current allocated size.
};

#endif
