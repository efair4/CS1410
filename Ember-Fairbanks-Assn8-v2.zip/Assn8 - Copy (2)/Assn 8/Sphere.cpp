#include "Sphere.hpp"

Sphere::Sphere(std::string name, double radius) :
	Geometry(name, "Sphere"),
	m_radius(radius)
{}

double Sphere::computeSurface() {
	return 4*PI*(m_radius*m_radius);
}

double Sphere::computeVolume() {
	return (4.0/3)*PI*(m_radius*m_radius*m_radius);
}