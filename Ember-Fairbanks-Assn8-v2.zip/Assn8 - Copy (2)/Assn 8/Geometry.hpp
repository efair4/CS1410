#ifndef _GEOMETRY_HPP_
#define _GEOMETRY_HPP_

#include <string>

class Geometry {
public:
	Geometry(std::string name, std::string type) :
		m_name(name),
		m_type(type)
	{}
	std::string getName() { return m_name; }
	std::string getType() { return m_type; }
	virtual double computeVolume()=0;
	virtual double computeSurface()=0;
protected:
	std::string m_name;
	std::string m_type;
};
#endif
