#ifndef _FISH_HPP_
#define _FISH_HPP_

#include "ProtoFish.hpp"
#include <vector>

class Fish : public ProtoFish {
public:
	//Constructor for Fish that sets the m_gestation, m_gestationPeriod
	//and the m_age for a Fish
	Fish(unsigned int, unsigned int, unsigned int);
	//This is called when the m_gestation reaches 0. The m_gestation is then
	//reset to the m_gestationPeriod
	bool haveBaby();
	//Overrides the timeUpdate() function from ProtoFish. Along with calling the 
	//ProtoFish timeUpdate() function, it also decrements the m_gestation and calls the
	//haveBaby() method if m_gestation reaches 0
	void timeUpdate();
	//This function makes the Fish point in a certain direction based on the location
	//of other fish in the sonar map. The Fish will point to the spot next to another fish.
	void point(std::vector<std::string>&);

protected:
	//Keeps track of the current gestation
	unsigned int m_gestation;
	//Holds the gestation period for a Fish
	unsigned int m_gestationPeriod;

private:
	//Helper function for the overriden point() function that checks to see if there
	//is a fish in a given location
	bool checkFish(std::vector<std::string>&, unsigned int, unsigned int);
};
#endif