#ifndef _SHARK_HPP_
#define _SHARK_HPP_

#include "Fish.hpp"

class Shark :public Fish {
public:
	//Default Constructor
	Shark(unsigned int, unsigned int, unsigned int, unsigned int, unsigned int);
	//Resets m_starvation to the starvation period
	void eat();
	//Overrides the toChar() function from ProtoFish and returns l,r,u, or d based
	//on the direction it is pointing.
	char toChar();
	//Overrides the timeUpdate() function from Fish and decrements the starvation countdown.
	void timeUpdate();
	//Overrides the point() function from Fish and points to the nearest fish instead
	//of next to it.
	void point(std::vector<std::string>& map);

protected:
	//Keeps track of the current starvation level
	unsigned int m_starvation;
	//Holds the starvation period for each shark
	unsigned int m_starvationPeriod;
	
private:
	//Helper function for the point() function that checks to see if there
	//is a fish in a given location
	bool checkFish(std::vector<std::string>&, unsigned int, unsigned int);
};
#endif
