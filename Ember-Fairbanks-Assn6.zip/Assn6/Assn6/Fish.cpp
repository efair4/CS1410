#include "Fish.hpp"

Fish::Fish(unsigned int gestation, unsigned int gestationPeriod, unsigned int startingAge) :
	ProtoFish(startingAge),
	m_gestation(gestation),
	m_gestationPeriod(gestationPeriod)
{
}

bool Fish::haveBaby() {
	if (m_gestation == 0) {
		m_gestation = m_gestationPeriod;
		return true;
	}
	return false;
}

void Fish::timeUpdate() {
	if (m_gestation > 0) {
		m_gestation--;
	}
	else {
		haveBaby();
	}
	ProtoFish::timeUpdate();
}

void Fish::point(std::vector<std::string>& map) {
	unsigned int row=0;
	unsigned int col=0;
	unsigned int tempFishRow;
	unsigned int tempFishCol;
	bool isFish;

	for (int i = 0; i < 5; i++) {
		isFish = checkFish(map, row, i);
		if (isFish == true) {
			tempFishRow = row;
			tempFishCol = i;
		}
	}
	row = 4;
	for (int i = 0; i < 5; i++) {
		isFish = checkFish(map, row, i);
		if (isFish == true) {
			tempFishRow = row;
			tempFishCol = i;
		}
	}
	for (int i = 1; i < 4; i++) {
		isFish = checkFish(map, i, col);
		if (isFish == true) {
			tempFishRow = i;
			tempFishCol = col;
		}
	}
	col = 4;
	for (int i = 1; i < 4; i++) {
		isFish = checkFish(map, i, col);
		if (isFish == true) {
			tempFishRow = i;
			tempFishCol = col;
		}
	}
	row = 1;
	for (int i = 1; i < 4; i+=2) {
		isFish = checkFish(map, row, i);
		if (isFish == true) {
			tempFishRow = row;
			tempFishCol = i;
		}
	}
	row = 3;
	for (int i = 1; i < 4; i+=2) {
		isFish = checkFish(map, row, i);
		if (isFish == true) {
			tempFishRow = row;
			tempFishCol = i;
		}
	}
	col = 2;
	isFish = checkFish(map, row, col);
	if (isFish == true) {
		tempFishRow = row;
		tempFishCol = col;
	}
	row = 1;
	isFish = checkFish(map, row, col);
	if (isFish == true) {
		tempFishRow = row;
		tempFishCol = col;
	}
	row = 2;
	col = 1;
	isFish = checkFish(map, row, col);
	if (isFish == true) {
		tempFishRow = row;
		tempFishCol = col;
	}
	col = 3;
	isFish = checkFish(map, row, col);
	if (isFish == true) {
		tempFishRow = row;
		tempFishCol = col;
	}

	switch (tempFishRow) {
		case 0:
			m_direction = Direction::up;
			break;
		case 1:
			switch (col) {
			case 0: case 1:
				m_direction = Direction::left;
				break;
			case 2:
				m_direction = Direction::right;
				break;
			case 3: case 4:
				m_direction = Direction::right;
				break;
			}
			break;
		case 2:
			switch (tempFishCol) {
			case 0:
				m_direction = Direction::left;
				break;
			case 1:
				m_direction = Direction::up;
				break;
			case 3:
				m_direction = Direction::down;
				break;
			case 4:
				m_direction = Direction::right;
			}
			break;
		case 3:
			switch (tempFishCol) {
			case 0: case 1:
				m_direction = Direction::left;
				break;
			case 2:
				m_direction = Direction::left;
				break;
			case 3: case 4:
				m_direction = Direction::right;
				break;
			}
			break;
		case 4:
			m_direction = Direction::down;
			break;
		}

	toChar();	
	
}

bool Fish::checkFish(std::vector<std::string>& map, unsigned int row, unsigned int col) {
	if (map[row][col] != '.') {
		return true;
	}
	return false;
}