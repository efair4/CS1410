#include <iostream>
#include <algorithm>
#include <cmath>

#include "BigInteger.hpp"


BigInteger::BigInteger() {
	m_sizeReserved = 4;
	m_digitCount = 0;
	m_number = new char[m_sizeReserved];

	for (unsigned int index = 0; index < m_sizeReserved; index++) {
		m_number[index] = 0;
	}
}

BigInteger::BigInteger(int intValue) {
	fromInt(intValue);
}

BigInteger::BigInteger(std::string strValue) {
	fromString(strValue);
}
// ------------------------------------------------------------------
//
// This method accepts a BigInteger and an integer, multiplies them
// together and returns a new BigInteger with the result.
//
// ------------------------------------------------------------------
BigInteger BigInteger::multiply(const BigInteger& x, unsigned int y)
{
	BigInteger result;
	unsigned int carry = 0;
	unsigned int pos = 0;

	for (unsigned int digit = 0; digit < x.m_digitCount; digit++)
	{
		carry += x.getDigit(digit) * y;
		result.setDigit(pos++, carry % 10);
		carry /= 10;
	}

	while (carry > 0)
	{
		result.setDigit(pos++, carry % 10);
		carry /= 10;
	}

	return result;
}

// ------------------------------------------------------------------
//
// Provides a means to display the BigInteger value.  Optionally, some
// debug information can be displayed by setting the 'debug' parameter
// to true.
//
// ------------------------------------------------------------------
void BigInteger::display(bool debug)
{
	for (unsigned int digit = m_digitCount; digit > 0; digit--)
	{
		std::cout << static_cast<int>(m_number[digit - 1]);
	}

	if (debug)
	{
		std::cout << " [size = " << m_sizeReserved << ", digit count = " << m_digitCount << std::endl;
	}
}
//Copy Constructor
BigInteger::BigInteger(const BigInteger& obj) {
	m_sizeReserved = obj.m_sizeReserved;
	m_number = new char[m_sizeReserved];

	for (unsigned int index = 0; index < m_sizeReserved; index++) {
		m_number[index] = 0;
	}

	m_digitCount = obj.m_digitCount;
	for (unsigned int position = 0; position < m_sizeReserved; position++) {
		m_number[position] = obj.m_number[position];
	}
}
//Assignment Operator
BigInteger& BigInteger::operator=(const BigInteger& rhs) {
	delete[]m_number;
	m_sizeReserved = rhs.m_sizeReserved;
	m_number = new char[m_sizeReserved];

	for (unsigned int index = 0; index < m_sizeReserved; index++) {
		m_number[index] = 0;
	}

	m_digitCount = rhs.m_digitCount;
	for (unsigned int position = 0; position < m_digitCount; position++) {
		m_number[position] = rhs.m_number[position];
	}
	return *this;
}

//Destructor
BigInteger::~BigInteger() {
	if (m_number !=nullptr) {
		delete[] m_number;
		m_number = nullptr;
	}
	
}

void BigInteger::fromInt(int intValue) {
	m_sizeReserved = 4;
	m_digitCount = 0;
	m_number = new char[m_sizeReserved];

	for (unsigned int index = 0; index < m_sizeReserved; index++) {
		m_number[index] = 0;
	}

	int i = 0;
	while (intValue>0) {
		int single = intValue % 10;
		intValue = intValue / 10;
		setDigit(i, single);
		i++;
	}
}

void BigInteger::fromString(std::string strValue) {
	m_sizeReserved = 4;
	m_digitCount = 0;
	m_number = new char[m_sizeReserved];

	for (unsigned int index = 0; index < m_sizeReserved; index++) {
		m_number[index] = 0;
	}

	for (int i = strValue.length() - 1, j = 0; i >= 0; i--, j++) {
		this->setDigit(j, strValue[i] - '0');
	}
}
// ------------------------------------------------------------------
//
// Returns the digit as the specified positon.  If the position is greater
// than the number representation, a '0' is returned.  Not the best
// idea in the world, but the best we can do for now, can make this better
// in the future.
//
// ------------------------------------------------------------------
char BigInteger::getDigit(unsigned int position) const
{
	if (position < m_digitCount)
	{
		return m_number[position];
	}

	return 0;
}

void BigInteger::setDigit(unsigned int position, char digit) {
	if (position >= m_sizeReserved) {
		resize(position);
	}
	m_number[position] = digit;
	if (position >= m_digitCount) {
		m_digitCount = position + 1;
	}
}

void BigInteger::resize(unsigned int position) {
	while (position >= m_sizeReserved) {
		m_sizeReserved *= 2;
	}
	char* temp = new char[m_sizeReserved];

	for (unsigned int index = 0; index < m_sizeReserved; index++) {
		temp[index] = 0;
	}

	for (int i = 0; i < m_digitCount; i++) {
		temp[i] = m_number[i];
	}
	delete[] m_number;
	m_number = temp;
}

//<< Operator Overload-good
std::ostream& operator<<(std::ostream& strm, const BigInteger& obj) {
	for (unsigned int digit = obj.m_digitCount; digit > 0; digit--)
	{
		std::cout << static_cast<int>(obj.m_number[digit - 1]);
	}
	return strm;
}

//+ Operator Overload-good
BigInteger BigInteger::operator+(const BigInteger& rhs) {
	BigInteger result;
	unsigned int length = (this->m_digitCount > rhs.m_digitCount) ? this->m_digitCount : rhs.m_digitCount;

	int carry = 0;
	for (unsigned int digit = 0; digit < length; digit++)
	{
		int v1 = this->getDigit(digit);
		int v2 = rhs.getDigit(digit);
		int sum = v1 + v2 + carry;
		int single = sum % 10;
		carry = ((sum - single) > 0) ? (sum - single) / 10 : 0;

		result.setDigit(digit, single);
	}
	if (carry > 0)
	{
		result.setDigit(length, carry);
	}

	return result;
}

//* Operator Overload-good
BigInteger BigInteger::operator*(const BigInteger& rhs) {
	BigInteger result;
	const BigInteger& b = (this->m_digitCount < rhs.m_digitCount) ? *this : rhs;
	const BigInteger& t = (this->m_digitCount < rhs.m_digitCount) ? rhs : *this;

	for (unsigned int bDigit = 0; bDigit < b.m_digitCount; bDigit++)
	{
		BigInteger temp(0);
		int v1 = b.getDigit(bDigit);
		int carry = 0;
		for (unsigned int tDigit = 0; tDigit < t.m_digitCount; tDigit++)
		{
			int v2 = t.getDigit(tDigit);
			int sum = v1 * v2 + carry;
			int single = sum % 10;
			carry = ((sum - single) > 0) ? (sum - single) / 10 : 0;

			temp.setDigit(bDigit + tDigit, single);
		}
		if (carry > 0)
		{
			temp.setDigit(bDigit + t.m_digitCount, carry);
		}
		result = result + temp;
	}

	return result;
}

//Move Constructor-good
BigInteger::BigInteger(BigInteger&& rhs) {
	m_digitCount = rhs.m_digitCount;
	m_sizeReserved = rhs.m_sizeReserved;
	m_number = rhs.m_number;

	rhs.m_sizeReserved = 0;
	rhs.m_digitCount = 0;
	rhs.m_number = nullptr;
}

//Move Assignment
BigInteger& BigInteger::operator=(BigInteger&& rhs) {
	if (this != &rhs) {
		std::swap(m_sizeReserved, rhs.m_sizeReserved);
		std::swap(m_digitCount, rhs.m_digitCount);
		std::swap(m_number, rhs.m_number);
	}
	return *this;
}

//+= Operator Overload-good
BigInteger BigInteger::operator+=(const BigInteger& rhs) {
	*this = this->operator+(rhs);
	return *this;
}

//*= Operator Overload-good
BigInteger BigInteger::operator*=(const BigInteger& rhs) {
	*this = this->operator*(rhs);
	return *this;
}

//++ Operator Overload-good
BigInteger BigInteger::operator++(int) {
	BigInteger temp;
	temp = *this;
	*this = this->operator+(BigInteger(1));
	return temp;
}

//+ Operator Overload for an int-good
BigInteger BigInteger::operator+(int number) {
	BigInteger result(number);
	result = result+*this;
	return result;
}

//<= Operator Overload-good
bool BigInteger::operator<=(const BigInteger& rhs) {
	if (this->m_digitCount < rhs.m_digitCount) return true;
	if (this->m_digitCount > rhs.m_digitCount) return false;
	// Have to go digit by digit
	for (int digit = m_digitCount - 1; digit >= 0; digit--) {
		if (this->m_number[digit] < rhs.m_number[digit]) return true;
		if (this->m_number[digit] > rhs.m_number[digit]) return false;
	}
	return true;
}

//== Operator Overload-good
bool BigInteger::operator==(const BigInteger& rhs) {
	if (this->m_digitCount != rhs.m_digitCount) {
		return false;
	}
	for (int digit = m_digitCount - 1; digit >= 0; digit--) {
		if (this->m_number[digit] != rhs.m_number[digit]) return false;
	}
	return true;
}

//Double Conversion-good
BigInteger::operator double() const{
	double multiplier = 1;
	double total = 0;
	for (unsigned int index = 0; index < m_sizeReserved; index++) {
		total += (m_number[index] * multiplier);
		multiplier *= 10;
	}
	return total;
}
